<?php $__env->startSection('content'); ?>
    <div class="mx-auto w-[min(1120px,calc(100%-1rem))] space-y-5">
        <section class="rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-5 py-6 text-white shadow-[0_18px_40px_rgba(18,52,87,0.16)] sm:rounded-[30px] sm:px-8 sm:py-8">
            <p class="text-[11px] uppercase tracking-[0.28em] text-blue-100">Checkout Donasi</p>
            <h1 class="mt-3 font-display text-[2.45rem] leading-none sm:text-[3.2rem]">Dukung <?php echo e($campaign->title); ?></h1>
            <p class="mt-4 max-w-3xl text-sm leading-7 text-blue-50/90">
                Setelah form dikirim, sistem akan membuat nomor referensi dan nominal transfer unik agar admin lebih mudah mencocokkan dana masuk di mutasi rekening.
            </p>
        </section>

        <section class="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
            <aside class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Ringkasan Campaign</p>
                <h2 class="mt-2 font-display text-[2rem] leading-none text-[#123457]"><?php echo e($campaign->title); ?></h2>
                <p class="mt-4 text-sm leading-7 text-[#31465d]"><?php echo e($campaign->summary); ?></p>

                <div class="mt-5 grid gap-3">
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Terkumpul</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">Rp <?php echo e(number_format((float) $campaign->current_amount, 0, ',', '.')); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Target</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">Rp <?php echo e(number_format((float) $campaign->target_amount, 0, ',', '.')); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Pengelola</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($campaign->organizer_name); ?></p>
                    </div>
                </div>
            </aside>

            <form method="POST" action="<?php echo e(route('donation.store', $campaign->slug)); ?>" data-dirty-form class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                <?php echo csrf_field(); ?>

                <div class="mb-5 rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] px-4 py-4 text-sm leading-7 text-[#31465d]">
                    <p class="font-semibold text-[#123457]">Alur transfer rekening</p>
                    <p class="mt-2">Isi data donasi, transfer sesuai total unik yang muncul, lalu kirim konfirmasi sederhana ke WhatsApp admin dari halaman status.</p>
                    <a href="<?php echo e(route('donation.lookup')); ?>" class="mt-3 inline-flex rounded-full bg-pm-blue px-4 py-2 text-xs font-semibold text-white">
                        Cek Status Donasi
                    </a>
                </div>

                <div class="grid gap-5 lg:grid-cols-2">
                    <label class="block lg:col-span-2">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nominal Donasi</span>
                        <input type="text" name="amount" inputmode="numeric" value="<?php echo e(old('amount')); ?>" data-money-input class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" placeholder="Contoh: 100000">
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-2 block text-xs text-[#b42318]"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>

                    <label class="block">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nama</span>
                        <input type="text" name="donor_name" value="<?php echo e(old('donor_name')); ?>" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" required>
                        <?php $__errorArgs = ['donor_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-2 block text-xs text-[#b42318]"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>

                    <label class="block">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nomor WhatsApp / HP</span>
                        <input type="text" name="donor_phone" value="<?php echo e(old('donor_phone')); ?>" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" required>
                        <?php $__errorArgs = ['donor_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-2 block text-xs text-[#b42318]"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>

                    <label class="block lg:col-span-2">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Email</span>
                        <input type="email" name="donor_email" value="<?php echo e(old('donor_email')); ?>" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                        <?php $__errorArgs = ['donor_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="mt-2 block text-xs text-[#b42318]"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>

                    <label class="block lg:col-span-2">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Doa / Pesan</span>
                        <textarea name="prayer_message" rows="5" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue"><?php echo e(old('prayer_message')); ?></textarea>
                    </label>

                    <label class="flex items-center gap-3 rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm font-medium text-[#23405f] lg:col-span-2">
                        <input type="hidden" name="is_anonymous" value="0">
                        <input type="checkbox" name="is_anonymous" value="1" <?php if(old('is_anonymous')): echo 'checked'; endif; ?> class="h-4 w-4 rounded border-[#b8c8d8] text-pm-blue focus:ring-pm-blue">
                        Tampilkan sebagai anonim di halaman publik
                    </label>
                </div>

                <div class="mt-6 flex flex-wrap justify-end gap-3">
                    <a href="<?php echo e(route('campaign.show', $campaign->slug)); ?>" class="rounded-full border border-[#dce6f1] px-5 py-3 text-sm font-medium text-[#23405f]">Kembali</a>
                    <button type="submit" class="rounded-full bg-pm-blue px-5 py-3 text-sm font-semibold text-white">Lanjut ke Instruksi Transfer</button>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\coding\ic\donasi-test-private\resources\views/pages/donation/create.blade.php ENDPATH**/ ?>
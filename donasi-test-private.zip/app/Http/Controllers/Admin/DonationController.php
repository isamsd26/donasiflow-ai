<?php

namespace App\Http\Controllers\Admin;

use App\Models\Donation;
use App\Support\CampaignMetrics;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Schema;
use Illuminate\Validation\Rule;
use App\Exports\DonationsExport;
use Maatwebsite\Excel\Facades\Excel;

class DonationController extends AdminController
{
    public function index(Request $request): View
    {
        $filters = $request->validate([
            'status' => ['nullable', Rule::in(['pending', 'paid', 'failed', 'expired', 'refunded'])],
            'q' => ['nullable', 'string', 'max:255'],
            'start_date' => ['nullable', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
        ]);

        $query = Donation::query()
            ->with('campaign')
            ->latest();

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['start_date'])) {
            $query->whereDate('created_at', '>=', $filters['start_date']);
        }

        if (! empty($filters['end_date'])) {
            $query->whereDate('created_at', '<=', $filters['end_date']);
        }

        if (! empty($filters['q'])) {
            $keyword = trim((string) $filters['q']);
            $digits = preg_replace('/[^\d]/', '', $keyword);

            $query->where(function ($query) use ($keyword, $digits): void {
                $query
                    ->where('reference', 'like', "%{$keyword}%")
                    ->orWhere('donor_name', 'like', "%{$keyword}%")
                    ->orWhere('donor_email', 'like', "%{$keyword}%")
                    ->orWhere('donor_phone', 'like', "%{$keyword}%")
                    ->orWhereHas('campaign', fn ($campaignQuery) => $campaignQuery->where('title', 'like', "%{$keyword}%"));

                if ($digits !== '') {
                    $query->orWhere('amount', (int) $digits);
                }
            });
        }

        return view('admin.donations.index', [
            'admin' => $this->adminShell(),
            'page' => $this->adminPage('donations'),
            'filters' => $filters,
            'donations' => $query->paginate(12)->withQueryString(),
        ]);
    }

    public function show(Donation $donation): View
    {
        $donation->load(['campaign']);
        return view('admin.donations.show', [
            'admin' => $this->adminShell(),
            'page' => $this->adminPage('donations'),
            'donation' => $donation,
        ]);
    }

    public function export(Request $request)
    {
        $filters = $request->validate([
            'status' => ['nullable', Rule::in(['pending', 'paid', 'failed', 'expired', 'refunded'])],
            'q' => ['nullable', 'string', 'max:255'],
            'start_date' => ['nullable', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
        ]);

        $fileName = 'Laporan-Donasi-' . now()->format('Ymd-Hi') . '.xlsx';

        return Excel::download(new DonationsExport($filters), $fileName);
    }

    public function updateStatus(Request $request, Donation $donation): RedirectResponse
    {
        $validated = $request->validate([
            'status' => ['required', Rule::in(['pending', 'paid', 'failed', 'expired', 'refunded'])],
            'admin_note' => ['nullable', 'string'],
        ]);

        $isPaid = $validated['status'] === 'paid';

        $update = [
            'status' => $validated['status'],
            'paid_at' => $isPaid ? now() : null,
        ];

        if (Schema::hasColumn('donations', 'verified_at')) {
            $update['verified_at'] = $isPaid ? now() : null;
        }

        if (Schema::hasColumn('donations', 'verified_by')) {
            $update['verified_by'] = $isPaid ? Auth::id() : null;
        }

        if (Schema::hasColumn('donations', 'admin_note')) {
            $update['admin_note'] = $validated['admin_note'] ?? null;
        }

        $donation->update($update);

        $donation->paymentTransactions()->latest()->first()?->update([
            'status' => $validated['status'],
            'paid_at' => $isPaid ? now() : null,
        ]);

        if ($donation->campaign) {
            CampaignMetrics::sync($donation->campaign);
        }

        return redirect()->route('admin.donations')->with('success', 'Status donasi berhasil diperbarui.');
    }
}

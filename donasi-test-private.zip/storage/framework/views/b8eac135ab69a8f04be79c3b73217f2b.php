<?php $__env->startSection('content'); ?>
    <div class="mx-auto w-[min(1120px,calc(100%-1rem))] space-y-5">
        <section class="grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
            <div class="overflow-hidden rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] shadow-[0_18px_40px_rgba(18,52,87,0.16)] sm:rounded-[30px]">
                <div class="relative min-h-[280px] p-5 text-white sm:min-h-[360px] sm:p-6" style="background: <?php echo e($campaign['cover']); ?>;">
                    <div class="absolute inset-0 bg-[linear-gradient(180deg,rgba(4,19,37,0.10),rgba(4,19,37,0.36))]"></div>
                    <div class="relative flex h-full flex-col justify-between">
                        <div class="flex items-start justify-between gap-3">
                            <span class="rounded-full border border-white/20 bg-white/12 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.18em]"><?php echo e($campaign['status_label']); ?></span>
                            <span class="rounded-full bg-black/20 px-3 py-1 text-[10px]"><?php echo e($campaign['days_left']); ?></span>
                        </div>

                        <div>
                            <p class="text-xs uppercase tracking-[0.2em] text-blue-100"><?php echo e($campaign['organizer']); ?></p>
                            <h1 class="mt-3 max-w-lg font-display text-[2.35rem] leading-[0.92] tracking-tight sm:text-[3.2rem]"><?php echo e($campaign['title']); ?></h1>
                            <p class="mt-4 max-w-xl text-sm leading-6 sm:leading-7 text-blue-50/90"><?php echo e($campaign['summary']); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="space-y-5">
                <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Progress Campaign</p>
                    <div class="mt-4 grid gap-4 sm:grid-cols-2">
                        <div>
                            <p class="text-xs text-pm-muted">Terkumpul</p>
                            <p class="mt-2 font-display text-[2rem] leading-none text-[#123457] sm:text-4xl"><?php echo e($campaign['collected']); ?></p>
                        </div>
                        <div>
                            <p class="text-xs text-pm-muted">Target</p>
                            <p class="mt-2 font-display text-[2rem] leading-none text-[#123457] sm:text-4xl"><?php echo e($campaign['target']); ?></p>
                        </div>
                    </div>

                    <div class="mt-4 h-2 rounded-full bg-[#dfe8f5]">
                        <div class="h-full rounded-full bg-pm-blue" style="width: <?php echo e($campaign['progress']); ?>%"></div>
                    </div>

                    <div class="mt-3 grid gap-3 sm:grid-cols-3">
                        <div class="rounded-2xl bg-[#f8fbff] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Progress</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($campaign['progress']); ?>%</p>
                        </div>
                        <div class="rounded-2xl bg-[#f8fbff] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Donatur</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($campaign['donor_count']); ?></p>
                        </div>
                        <div class="rounded-2xl bg-[#f8fbff] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Sisa Waktu</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($campaign['days_left']); ?></p>
                        </div>
                    </div>

                    <div class="mt-5 flex flex-wrap gap-3">
                        <?php if($campaign['status'] === 'active'): ?>
                            <a href="<?php echo e(route('donation.create', ['slug' => $campaign['slug']])); ?>" class="inline-flex rounded-full bg-pm-blue px-5 py-3 text-sm font-semibold text-white">Donasi Sekarang</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('donation.lookup')); ?>" class="inline-flex rounded-full border border-[#d9e2ef] bg-[#f8fbff] px-3.5 py-2.5 text-sm font-medium text-[#23405f] sm:px-4 sm:py-3">
                            Cek Status Donasi
                        </a>
                        <?php $__currentLoopData = $campaign['share_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($link['url']); ?>" class="inline-flex rounded-full border border-[#d9e2ef] bg-[#f8fbff] px-3.5 py-2.5 text-sm font-medium text-[#23405f] sm:px-4 sm:py-3">
                                <?php echo e($link['label']); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Informasi Khusus</p>
                    <div class="mt-4 grid gap-3">
                        <?php $__currentLoopData = $campaign['meta']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex flex-col gap-1 rounded-2xl border border-[#e6edf6] px-4 py-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
                                <span class="text-sm text-pm-muted"><?php echo e($label); ?></span>
                                <span class="text-sm font-semibold text-[#123457]"><?php echo e($value); ?></span>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="grid gap-5 lg:grid-cols-[1fr_0.34fr]">
            <div class="rounded-[24px] bg-white shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px]">
                <div class="border-b border-[#e7edf5] px-4 py-4 sm:px-6 sm:py-5">
                    <div class="flex flex-wrap gap-2" id="detail-tabs">
                        <button type="button" class="rounded-full border border-pm-blue bg-pm-blue px-4 py-2 text-sm font-semibold text-white" data-tab-target="summary">Rangkuman</button>
                        <button type="button" class="rounded-full border border-[#d6dfeb] bg-[#f8fbff] px-4 py-2 text-sm font-semibold text-pm-blue" data-tab-target="updates">Kabar Terbaru</button>
                        <button type="button" class="rounded-full border border-[#d6dfeb] bg-[#f8fbff] px-4 py-2 text-sm font-semibold text-pm-blue" data-tab-target="donors">Donatur</button>
                    </div>
                </div>

                <div class="px-4 py-5 sm:px-6 sm:py-6">
                    <div data-tab-panel="summary">
                        <h2 class="font-display text-[2rem] leading-none text-[#123457] sm:text-3xl">Rangkuman Campaign</h2>
                        <div class="mt-4 space-y-4 text-sm leading-7 text-[#31465d]">
                            <?php $__empty_1 = true; $__currentLoopData = $campaign['story']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p><?php echo e($paragraph); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Konten campaign belum diisi dari CMS.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="hidden space-y-4" data-tab-panel="updates">
                        <?php $__empty_1 = true; $__currentLoopData = $campaign['updates']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article class="rounded-[24px] border border-[#e6edf6] bg-[#fbfdff] px-4 py-4 sm:px-5 sm:py-5">
                                <div class="flex flex-wrap items-center justify-between gap-3">
                                    <h3 class="font-display text-[1.7rem] leading-none text-[#123457] sm:text-2xl"><?php echo e($update['title']); ?></h3>
                                    <span class="text-xs font-semibold uppercase tracking-[0.12em] text-pm-muted"><?php echo e($update['date']); ?></span>
                                </div>
                                <p class="mt-3 text-sm leading-7 text-[#31465d]"><?php echo e($update['body']); ?></p>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="rounded-[24px] border border-dashed border-[#d7e3ef] px-5 py-8 text-sm text-[#56708e]">
                                Belum ada kabar terbaru untuk campaign ini.
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="hidden space-y-4" data-tab-panel="donors">
                        <?php $__empty_1 = true; $__currentLoopData = $campaign['donors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="rounded-[22px] border border-[#e6edf6] bg-[#fbfdff] px-4 py-4 sm:px-5">
                                <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                                    <div>
                                        <p class="text-sm font-semibold text-[#123457]"><?php echo e($donor['name']); ?></p>
                                        <p class="mt-1 text-xs text-pm-muted"><?php echo e($donor['date']); ?></p>
                                    </div>
                                    <p class="text-sm font-semibold text-pm-blue"><?php echo e($donor['amount']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="rounded-[24px] border border-dashed border-[#d7e3ef] px-5 py-8 text-sm text-[#56708e]">
                                Belum ada donasi publik yang bisa ditampilkan.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <aside class="space-y-5">
                <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Donasi Terbaru</p>
                    <div class="mt-4 space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $latestDonations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="rounded-2xl border border-[#e6edf6] bg-[#f9fbff] px-4 py-3">
                                <p class="text-sm font-semibold text-[#15375f]"><?php echo e($donation['name']); ?></p>
                                <div class="mt-3 flex items-center justify-between text-xs text-pm-muted">
                                    <span><?php echo e($donation['date']); ?></span>
                                    <span class="font-semibold text-pm-blue"><?php echo e($donation['amount']); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="rounded-[24px] border border-dashed border-[#d7e3ef] px-4 py-6 text-sm text-[#56708e]">
                                Belum ada donasi terbaru.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-4 py-5 text-white shadow-[0_16px_34px_rgba(14,44,82,0.12)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] uppercase tracking-[0.18em] text-blue-100">Campaign Terkait</p>
                    <div class="mt-4 space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $relatedCampaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="<?php echo e(route('campaign.show', ['slug' => $related['slug']])); ?>" class="block rounded-2xl border border-white/12 bg-white/10 px-4 py-4">
                                <p class="text-sm font-semibold text-white"><?php echo e($related['title']); ?></p>
                                <p class="mt-1 text-xs text-blue-100"><?php echo e($related['days_left']); ?></p>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="rounded-2xl border border-white/12 bg-white/10 px-4 py-4 text-sm text-blue-50/90">
                                Belum ada campaign terkait dalam kategori yang sama.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </aside>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        (() => {
            const buttons = Array.from(document.querySelectorAll('[data-tab-target]'));
            const panels = Array.from(document.querySelectorAll('[data-tab-panel]'));

            buttons.forEach((button) => {
                button.addEventListener('click', () => {
                    const target = button.dataset.tabTarget;

                    buttons.forEach((item) => {
                        item.classList.toggle('border-pm-blue', item === button);
                        item.classList.toggle('bg-pm-blue', item === button);
                        item.classList.toggle('text-white', item === button);
                        item.classList.toggle('text-pm-blue', item !== button);
                        item.classList.toggle('border-[#d6dfeb]', item !== button);
                        item.classList.toggle('bg-[#f8fbff]', item !== button);
                    });

                    panels.forEach((panel) => {
                        panel.classList.toggle('hidden', panel.dataset.tabPanel !== target);
                    });
                });
            });
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\coding\donasi-test-private\resources\views/pages/campaign/show.blade.php ENDPATH**/ ?>
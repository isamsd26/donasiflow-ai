@extends('layouts.admin')

@section('content')
    <section class="rounded-[26px] bg-white shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
        <div class="flex items-center justify-between border-b border-[#e4edf6] px-5 py-5">
            <div>
                <a href="{{ route('admin.donations') }}" class="inline-flex items-center gap-2 text-sm font-semibold text-pm-blue hover:underline mb-2">
                    <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    Kembali ke Daftar Donasi
                </a>
                <h2 class="mt-1 font-display text-3xl leading-none text-[#123457]">Detail Donasi: {{ $donation->reference }}</h2>
            </div>
            <div>
                <span class="rounded-full bg-[#eef5ff] px-4 py-2 text-sm font-semibold text-pm-blue">{{ str($donation->status)->headline() }}</span>
            </div>
        </div>

        <div class="grid gap-6 p-6 lg:grid-cols-2">
            <div class="space-y-6">
                <!-- Informasi Donatur -->
                <div class="rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] p-5">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue mb-4">Informasi Donatur</p>
                    <div class="space-y-4 text-sm text-[#123457]">
                        <div>
                            <p class="text-xs text-pm-muted">Nama</p>
                            <p class="font-semibold">{{ $donation->donor_name }} @if($donation->is_anonymous) <span class="ml-2 text-xs text-[#56708e]">(Tampil sebagai Anonim)</span> @endif</p>
                        </div>
                        <div>
                            <p class="text-xs text-pm-muted">Email</p>
                            <p class="font-semibold">{{ $donation->donor_email ?: '-' }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-pm-muted">No. HP / WhatsApp</p>
                            <p class="font-semibold">{{ $donation->donor_phone ?: '-' }}</p>
                        </div>
                        <div>
                            <p class="text-xs text-pm-muted">Doa & Pesan</p>
                            @if($donation->prayer_message)
                                <div class="mt-1 rounded-xl bg-white p-3 border border-[#e4edf6] italic text-[#31465d]">
                                    "{{ $donation->prayer_message }}"
                                </div>
                            @else
                                <p class="font-semibold">-</p>
                            @endif
                        </div>
                    </div>
                </div>

                <!-- Informasi Campaign -->
                <div class="rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] p-5">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue mb-4">Tujuan Donasi</p>
                    <div class="space-y-4 text-sm text-[#123457]">
                        <div>
                            <p class="text-xs text-pm-muted">Campaign</p>
                            <p class="font-semibold">{{ $donation->campaign?->title ?? '-' }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="space-y-6">
                <!-- Rincian Nominal -->
                <div class="rounded-2xl border border-[#d6e4f1] bg-white shadow-sm p-5">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue mb-4">Rincian Nominal</p>
                    <div class="space-y-3 text-sm text-[#123457]">
                        <div class="flex justify-between border-b border-gray-100 pb-2">
                            <span class="text-pm-muted">Nilai Donasi</span>
                            <span class="font-semibold">Rp {{ number_format((float) ($donation->base_amount ?: $donation->amount), 0, ',', '.') }}</span>
                        </div>
                        <div class="flex justify-between border-b border-gray-100 pb-2">
                            <span class="text-pm-muted">Kode Unik</span>
                            <span class="font-semibold">Rp {{ number_format((int) $donation->unique_code, 0, ',', '.') }}</span>
                        </div>
                        <div class="flex justify-between pt-1">
                            <span class="font-bold">Total Transfer</span>
                            <span class="text-lg font-bold text-pm-blue">Rp {{ number_format((float) $donation->amount, 0, ',', '.') }}</span>
                        </div>
                    </div>
                </div>

                <!-- Informasi Transfer -->
                <div class="rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] p-5">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue mb-4">Waktu & Verifikasi</p>
                    <div class="space-y-4 text-sm text-[#123457]">
                        <div>
                            <p class="text-xs text-pm-muted">Waktu Dibuat</p>
                            <p class="font-semibold">{{ $donation->created_at->translatedFormat('d F Y, H:i:s') }}</p>
                        </div>
                        @if($donation->expires_at)
                        <div>
                            <p class="text-xs text-pm-muted">Batas Waktu Pending</p>
                            <p class="font-semibold">{{ $donation->expires_at->translatedFormat('d F Y, H:i:s') }}</p>
                        </div>
                        @endif
                        @if($donation->paid_at)
                        <div>
                            <p class="text-xs text-pm-muted">Waktu Lunas (Paid)</p>
                            <p class="font-semibold text-[#18794e]">{{ $donation->paid_at->translatedFormat('d F Y, H:i:s') }}</p>
                        </div>
                        @endif
                        @if($donation->admin_note)
                        <div>
                            <p class="text-xs text-pm-muted">Catatan Admin</p>
                            <p class="font-semibold">{{ $donation->admin_note }}</p>
                        </div>
                        @endif
                    </div>
                </div>
                

            </div>
        </div>
    </section>


@endsection

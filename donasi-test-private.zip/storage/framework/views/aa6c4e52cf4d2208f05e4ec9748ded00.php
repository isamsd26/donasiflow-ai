<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <section class="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <?php $__currentLoopData = $dashboard['stats']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="rounded-[24px] bg-white px-5 py-5 shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue"><?php echo e($stat['label']); ?></p>
                    <p class="mt-3 font-display text-4xl leading-none text-[#123457]"><?php echo e($stat['value']); ?></p>
                    <p class="mt-3 text-sm leading-6 text-[#56708e]"><?php echo e($stat['note']); ?></p>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>

        <section class="grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
            <div class="rounded-[26px] bg-white shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
                <div class="border-b border-[#e4edf6] px-5 py-5">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Transaksi Terbaru</p>
                    <h2 class="mt-1 font-display text-3xl leading-none text-[#123457]">Ringkasan aktivitas donasi terbaru.</h2>
                </div>

                <div class="overflow-x-auto px-5 py-5">
                    <table class="min-w-full text-left text-sm">
                        <thead class="text-[#56708e]">
                            <tr class="border-b border-[#e9eff6]">
                                <th class="pb-3 font-semibold">Reference</th>
                                <th class="pb-3 font-semibold">Campaign</th>
                                <th class="pb-3 font-semibold">Donor</th>
                                <th class="pb-3 font-semibold">Nominal</th>
                                <th class="pb-3 font-semibold">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $dashboard['recent_transactions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-b border-[#eef3f8] last:border-b-0">
                                    <td class="py-3 text-[#123457]"><?php echo e($row->reference); ?></td>
                                    <td class="py-3 text-[#123457]"><?php echo e($row->campaign?->title ?? '-'); ?></td>
                                    <td class="py-3 text-[#56708e]"><?php echo e($row->is_anonymous ? 'Anonim' : $row->donor_name); ?></td>
                                    <td class="py-3 font-semibold text-pm-blue">Rp <?php echo e(number_format((float) $row->amount, 0, ',', '.')); ?></td>
                                    <td class="py-3">
                                        <span class="rounded-full px-3 py-1 text-xs font-semibold <?php echo e($row->status === 'paid' ? 'bg-[#dff4e8] text-[#18794e]' : 'bg-[#fff4da] text-[#9a6700]'); ?>">
                                            <?php echo e(str($row->status)->headline()); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="py-6 text-center text-sm text-[#56708e]">Belum ada transaksi untuk ditampilkan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="space-y-5">
                <div class="rounded-[26px] bg-white px-5 py-5 shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Campaign Hampir Berakhir</p>
                    <div class="mt-4 space-y-3">
                        <?php $__empty_1 = true; $__currentLoopData = $dashboard['ending_campaigns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="rounded-2xl border border-[#e5edf6] bg-[#f8fbff] px-4 py-4">
                                <div class="flex items-start justify-between gap-3">
                                    <div>
                                        <p class="text-sm font-semibold text-[#123457]"><?php echo e($campaign['title']); ?></p>
                                        <p class="mt-1 text-xs text-pm-muted"><?php echo e($campaign['days_left']); ?></p>
                                    </div>
                                    <span class="rounded-full bg-pm-blue-soft px-2 py-1 text-[10px] font-semibold text-pm-blue"><?php echo e($campaign['progress']); ?></span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="rounded-2xl border border-dashed border-[#d7e3ef] px-4 py-5 text-sm text-[#56708e]">
                                Belum ada campaign dengan tanggal selesai yang tercatat.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="rounded-[26px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-5 py-6 text-white shadow-[0_14px_28px_rgba(14,44,82,0.14)]">
                    <p class="text-[10px] uppercase tracking-[0.18em] text-blue-100">Arah Implementasi</p>
                    <p class="mt-3 text-sm leading-7 text-blue-50/90">
                        Dashboard ini sudah disiapkan sebagai shell administrasi. Setelah migration dan model dibuat, tiap widget bisa langsung disambungkan ke data nyata tanpa perlu mengubah layout dasarnya.
                    </p>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\coding\ic\donasi-test-private\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
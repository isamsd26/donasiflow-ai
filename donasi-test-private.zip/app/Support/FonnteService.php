<?php

namespace App\Support;

use App\Models\Donation;
use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class FonnteService
{
    public static function isEnabled(): bool
    {
        // By default check if FONNTE_ENABLED is true in .env, otherwise check settings
        if (env('FONNTE_ENABLED', false)) {
            return true;
        }

        $setting = Setting::query()->where('key', 'fonnte_enabled')->first();
        return $setting && ($setting->value['value'] ?? false);
    }

    public static function getToken(): ?string
    {
        // Prioritize env variable if set, otherwise from settings
        $envToken = env('FONNTE_TOKEN');
        if ($envToken) {
            return $envToken;
        }

        $setting = Setting::query()->where('key', 'fonnte_token')->first();
        return $setting->value['value'] ?? null;
    }

    public static function getTemplate(): string
    {
        $setting = Setting::query()->where('key', 'fonnte_wa_template')->first();
        
        $defaultTemplate = "Assalamu'alaikum {nama}, terima kasih sudah berdonasi untuk campaign {campaign}. Mohon segera transfer Rp {jumlah} ke rekening {bank} {no_rek} a.n {atas_nama} sebelum {batas_waktu}. Setelah transfer, konfirmasi ke admin kami. Jazakallah khair";

        $template = $setting->value['value'] ?? null;
        return $template ?: $defaultTemplate;
    }

    public static function buildDonationPendingMessage(Donation $donation): string
    {
        $template = self::getTemplate();

        $replacements = [
            '{nama}' => $donation->donor_name,
            '{campaign}' => $donation->campaign?->title ?? '-',
            '{jumlah}' => number_format((float) $donation->amount, 0, ',', '.'),
            '{bank}' => $donation->payment_bank ?: 'BSI',
            '{no_rek}' => $donation->payment_account_number ?: '-',
            '{atas_nama}' => $donation->payment_account_name ?: '-',
            '{batas_waktu}' => $donation->expires_at ? $donation->expires_at->translatedFormat('d M Y, H:i') : '-',
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $template);
    }

    public static function send(string $phone, string $message): bool
    {
        if (!self::isEnabled()) {
            return false;
        }

        $token = self::getToken();

        if (!$token) {
            Log::warning('Fonnte token is missing, cannot send WhatsApp message to ' . $phone);
            return false;
        }

        try {
            $response = Http::withoutVerifying()->withHeaders([
                'Authorization' => $token,
            ])->post('https://api.fonnte.com/send', [
                'target' => $phone,
                'message' => $message,
                'countryCode' => '62',
            ]);

            if ($response->successful()) {
                $data = $response->json();
                if (isset($data['status']) && $data['status'] === true) {
                    return true;
                }
                Log::warning('Fonnte API returned false status', ['response' => $data]);
            } else {
                Log::warning('Fonnte API failed', ['status' => $response->status(), 'response' => $response->body()]);
            }
        } catch (\Exception $e) {
            Log::error('Fonnte exception: ' . $e->getMessage());
        }

        return false;
    }
}

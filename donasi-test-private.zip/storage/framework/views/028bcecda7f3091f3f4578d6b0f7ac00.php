<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e($page['title'] ?? 'Admin'); ?> - <?php echo e($admin['brand'] ?? 'CMS Admin'); ?></title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=oswald:400,500,600,700|instrument-sans:400,500,600,700" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="bg-[#eef3f8] text-[#16304f]">
        <div class="min-h-screen lg:grid lg:grid-cols-[280px_1fr]">
            <div class="fixed inset-0 z-40 hidden bg-[#0b2743]/55 lg:hidden" data-admin-sidebar-backdrop></div>
            <?php echo $__env->make('layouts.partials.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="min-h-screen min-w-0">
                <?php echo $__env->make('layouts.partials.admin-topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <main class="px-4 py-5 sm:px-6 lg:px-8">
                    <?php if(session('success')): ?>
                        <div class="mb-5 rounded-2xl border border-[#cce7d9] bg-[#edf9f2] px-4 py-3 text-sm font-medium text-[#18794e]">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="mb-5 rounded-2xl border border-[#f2d4d4] bg-[#fff2f2] px-4 py-3 text-sm font-medium text-[#b42318]">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="mb-5 rounded-2xl border border-[#f2d4d4] bg-[#fff7f7] px-4 py-4 text-sm text-[#8f1d1d] shadow-[0_10px_18px_rgba(180,35,24,0.05)]">
                            <p class="font-semibold">Form belum bisa disimpan. Silakan cek bagian berikut:</p>
                            <ul class="mt-2 space-y-1">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>- <?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
        </div>
    </body>
</html>
<?php /**PATH F:\coding\donasi-test-private\resources\views/layouts/admin.blade.php ENDPATH**/ ?>
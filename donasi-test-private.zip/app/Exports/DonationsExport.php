<?php

namespace App\Exports;

use App\Models\Donation;
use Illuminate\Database\Eloquent\Builder;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithCustomValueBinder;
use Maatwebsite\Excel\Concerns\WithEvents;
use PhpOffice\PhpSpreadsheet\Cell\Cell;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Cell\DefaultValueBinder;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class DonationsExport extends DefaultValueBinder implements FromQuery, WithHeadings, WithMapping, WithCustomValueBinder, WithEvents, WithColumnFormatting, ShouldAutoSize
{
    use Exportable;

    protected array $filters;

    public function __construct(array $filters)
    {
        $this->filters = $filters;
    }

    public function query()
    {
        $query = Donation::query()
            ->with('campaign')
            ->orderBy('created_at', 'asc');

        if (!empty($this->filters['status'])) {
            $query->where('status', $this->filters['status']);
        }

        if (!empty($this->filters['start_date'])) {
            $query->whereDate('created_at', '>=', $this->filters['start_date']);
        }

        if (!empty($this->filters['end_date'])) {
            $query->whereDate('created_at', '<=', $this->filters['end_date']);
        }

        if (!empty($this->filters['q'])) {
            $keyword = trim((string) $this->filters['q']);
            $digits = preg_replace('/[^\d]/', '', $keyword);

            $query->where(function (Builder $q) use ($keyword, $digits) {
                $q->where('reference', 'like', "%{$keyword}%")
                  ->orWhere('donor_name', 'like', "%{$keyword}%")
                  ->orWhere('donor_email', 'like', "%{$keyword}%")
                  ->orWhere('donor_phone', 'like', "%{$keyword}%")
                  ->orWhereHas('campaign', fn ($campaignQuery) => $campaignQuery->where('title', 'like', "%{$keyword}%"));

                if ($digits !== '') {
                    $q->orWhere('amount', (int) $digits);
                }
            });
        }

        return $query;
    }

    public function headings(): array
    {
        return [
            'Tanggal Dibuat',
            'Tanggal Lunas',
            'No. Referensi',
            'Nama Donatur',
            'No. Telepon',
            'Nama Campaign',
            'Nominal Dasar',
            'Kode Unik',
            'Total Transfer',
            'Status',
            'Catatan Admin'
        ];
    }

    public function map($donation): array
    {
        return [
            $donation->created_at->format('Y-m-d H:i:s'),
            $donation->paid_at ? $donation->paid_at->format('Y-m-d H:i:s') : '-',
            $donation->reference,
            $donation->is_anonymous ? 'Anonim (' . $donation->donor_name . ')' : $donation->donor_name,
            $donation->donor_phone,
            $donation->campaign ? $donation->campaign->title : '-',
            $donation->base_amount ?: $donation->amount,
            $donation->unique_code ?: 0,
            $donation->amount,
            str($donation->status)->headline(),
            $donation->admin_note
        ];
    }

    public function columnFormats(): array
    {
        $rupiahFormat = '"Rp" #,##0_-';
        
        return [
            'G' => $rupiahFormat,
            'H' => $rupiahFormat,
            'I' => $rupiahFormat,
        ];
    }

    public function bindValue(Cell $cell, $value)
    {
        if (is_numeric($value) && in_array($cell->getColumn(), ['G', 'H', 'I'])) {
            $cell->setValueExplicit($value, DataType::TYPE_NUMERIC);
            return true;
        }

        // Return default behavior
        return parent::bindValue($cell, $value);
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $totalRow = $highestRow + 1;
                
                $event->sheet->setCellValue('A' . $totalRow, 'TOTAL');
                $event->sheet->mergeCells("A{$totalRow}:F{$totalRow}");
                
                $event->sheet->setCellValue('G' . $totalRow, "=SUM(G2:G{$highestRow})");
                $event->sheet->setCellValue('H' . $totalRow, "=SUM(H2:H{$highestRow})");
                $event->sheet->setCellValue('I' . $totalRow, "=SUM(I2:I{$highestRow})");
                
                $event->sheet->getStyle("A1:K1")->getFont()->setBold(true);
                $event->sheet->getStyle("A{$totalRow}:K{$totalRow}")->getFont()->setBold(true);

                // Tambahkan Border untuk seluruh tabel
                $event->sheet->getStyle("A1:K{$totalRow}")->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                            'color' => ['argb' => 'FF000000'],
                        ],
                    ],
                ]);

                // Pastikan baris TOTAL juga diformat Rupiah
                $rupiahFormat = '"Rp" #,##0_-';
                $event->sheet->getStyle("G{$totalRow}:I{$totalRow}")->getNumberFormat()->setFormatCode($rupiahFormat);
            },
        ];
    }
}

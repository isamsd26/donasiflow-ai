<header class="mx-auto w-[min(1120px,calc(100%-1rem))]">
    <div class="rounded-[10px] bg-pm-blue px-4 py-3 text-white shadow-[0_10px_24px_rgba(18,52,87,0.16)] sm:px-6">
        <div class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div class="text-center lg:text-left">
                <a href="<?php echo e(route('home')); ?>" class="font-display text-[2rem] leading-none"><?php echo e($site['name'] ?? 'Donasi Harapan'); ?></a>
                <p class="mt-1 text-[10px] uppercase tracking-[0.28em] text-blue-100"><?php echo e($site['tagline'] ?? 'Campaign stories for real-world impact'); ?></p>
            </div>

            <nav class="flex flex-wrap items-center justify-center gap-2 text-xs">
                <?php $__currentLoopData = $navigation ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a
                        href="<?php echo e(route($item['route'], $item['params'] ?? [])); ?>"
                        class="rounded-full border border-white/18 bg-white/8 px-3 py-1.5 font-medium text-white transition hover:bg-white/14"
                    >
                        <?php echo e($item['label']); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH F:\coding\ic\donasi-test-private\resources\views/layouts/partials/public-header.blade.php ENDPATH**/ ?>
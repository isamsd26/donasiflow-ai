@extends('layouts.public')

@section('content')
    <div class="mx-auto w-[min(980px,calc(100%-1rem))] space-y-5">
        <section class="rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-5 py-6 text-white shadow-[0_18px_40px_rgba(18,52,87,0.16)] sm:rounded-[30px] sm:px-8 sm:py-8">
            <p class="text-[11px] uppercase tracking-[0.28em] text-blue-100">Cek Status Donasi</p>
            <h1 class="mt-3 font-display text-[2.45rem] leading-none sm:text-[3.2rem]">Masukkan nomor referensi</h1>
            <p class="mt-4 max-w-3xl text-sm leading-7 text-blue-50/90">
                Halaman ini bisa dipakai tanpa login. Cukup masukkan nomor referensi donasi, lalu sistem akan menampilkan status dengan informasi yang aman dan minimal.
            </p>
        </section>

        <section class="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
            <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                <form method="GET" action="{{ route('donation.lookup') }}" class="space-y-4">
                    <label class="block">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nomor Referensi</span>
                        <input
                            type="text"
                            name="reference"
                            value="{{ $reference }}"
                            class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm uppercase outline-none focus:border-pm-blue"
                            placeholder="Contoh: INV-20260324-4084"
                        >
                    </label>

                    <div class="flex flex-wrap gap-3">
                        <button type="submit" class="rounded-full bg-pm-blue px-5 py-3 text-sm font-semibold text-white">Cek Status</button>
                        @if ($reference !== '')
                            <a href="{{ route('donation.lookup') }}" class="rounded-full border border-[#dce6f1] px-5 py-3 text-sm font-medium text-[#23405f]">Reset</a>
                        @endif
                    </div>
                </form>

                <div class="mt-5 rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] px-4 py-4 text-sm leading-7 text-[#31465d]">
                    <p class="font-semibold text-[#123457]">Catatan</p>
                    <p class="mt-2">Simpan nomor referensi atau link status setelah mengirim donasi. Halaman ini sengaja tidak menampilkan data pribadi donatur.</p>
                </div>
            </div>

            <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Hasil Pencarian</p>

                @if ($reference === '')
                    <div class="mt-4 rounded-2xl border border-dashed border-[#d6e4f1] px-4 py-5 text-sm leading-7 text-[#5f7287]">
                        Masukkan nomor referensi di samping untuk melihat status donasi Anda.
                    </div>
                @elseif (! $result)
                    <div class="mt-4 rounded-2xl border border-[#f2d6d2] bg-[#fff6f5] px-4 py-5 text-sm leading-7 text-[#8a2d24]">
                        Nomor referensi tidak ditemukan. Pastikan kode yang dimasukkan sudah benar.
                    </div>
                @else
                    @php
                        $statusMeta = [
                            'pending' => ['label' => 'Menunggu Transfer', 'class' => 'bg-[#fff4da] text-[#9a6700]'],
                            'paid' => ['label' => 'Donasi Diterima', 'class' => 'bg-[#e8f8ef] text-[#18794e]'],
                            'failed' => ['label' => 'Verifikasi Gagal', 'class' => 'bg-[#fff1f1] text-[#b42318]'],
                            'expired' => ['label' => 'Kedaluwarsa', 'class' => 'bg-[#eef2f6] text-[#56708e]'],
                            'refunded' => ['label' => 'Dikembalikan', 'class' => 'bg-[#eef5ff] text-pm-blue'],
                        ][$result->status] ?? ['label' => str($result->status)->headline(), 'class' => 'bg-[#eef5ff] text-pm-blue'];
                    @endphp
                    <div class="mt-4 grid gap-3">
                        <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Referensi</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]">{{ $result->reference }}</p>
                        </div>
                        <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Campaign</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]">{{ $result->campaign?->title ?? '-' }}</p>
                        </div>
                        <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Total Transfer</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]">Rp {{ number_format((float) $result->amount, 0, ',', '.') }}</p>
                        </div>
                        <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Status</p>
                            <p class="mt-2 inline-flex rounded-full px-3 py-1 text-sm font-semibold {{ $statusMeta['class'] }}">{{ $statusMeta['label'] }}</p>
                        </div>
                        <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Detail Lengkap</p>
                            <a href="{{ route('donation.show', $result->reference) }}" class="mt-2 inline-flex rounded-full bg-pm-blue px-4 py-2 text-sm font-semibold text-white">Buka Halaman Status</a>
                        </div>
                    </div>
                @endif
            </div>
        </section>
    </div>
@endsection

<?php

namespace Database\Seeders;

use App\Models\Campaign;
use App\Models\CampaignCategory;
use App\Models\CampaignUpdate;
use App\Models\Donation;
use App\Models\Donor;
use App\Models\FaqItem;
use App\Models\HeroBanner;
use App\Models\Setting;
use App\Models\StaticPage;
use App\Models\Testimonial;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        $this->seedAdminUser();
        $this->seedSettings();
        $categories = $this->seedCategories();
        $campaigns = $this->seedCampaigns($categories);
        $this->seedCampaignUpdates($campaigns);
        $this->seedHeroBanners($campaigns);
        $this->seedStaticPages();
        $this->seedFaqItems();
        $this->seedTestimonials();
        $this->seedDonorsAndDonations($campaigns);
        $this->refreshCampaignStats($campaigns);
    }

    private function seedAdminUser(): void
    {
        if (app()->environment(['local', 'testing'])) {
            User::query()->updateOrCreate(
                ['email' => 'admin@example.com'],
                [
                    'name' => 'Admin Utama',
                    'password' => Hash::make('password'),
                ]
            );

            return;
        }

        $email = env('ADMIN_INITIAL_EMAIL');
        $password = env('ADMIN_INITIAL_PASSWORD');

        if (! $email || ! $password) {
            return;
        }

        User::query()->updateOrCreate(
            ['email' => $email],
            [
                'name' => env('ADMIN_INITIAL_NAME', 'Admin Utama'),
                'password' => Hash::make($password),
            ]
        );
    }

    private function seedSettings(): void
    {
        $settings = [
            ['group' => 'identity', 'key' => 'site_name', 'label' => 'Nama Situs', 'type' => 'text', 'value' => ['value' => 'Donasi Harapan']],
            ['group' => 'identity', 'key' => 'site_tagline', 'label' => 'Tagline Situs', 'type' => 'text', 'value' => ['value' => 'Campaign stories for real-world impact']],
            ['group' => 'impact', 'key' => 'impact_total_beneficiaries', 'label' => 'Total Penerima Manfaat', 'type' => 'text', 'value' => ['value' => '900,000']],
            ['group' => 'contact', 'key' => 'contact_email', 'label' => 'Email Kontak', 'type' => 'email', 'value' => ['value' => 'halo@donasiharapan.test']],
            ['group' => 'contact', 'key' => 'whatsapp', 'label' => 'WhatsApp', 'type' => 'text', 'value' => ['value' => '0812-0000-0000']],
            ['group' => 'contact', 'key' => 'contact_address', 'label' => 'Alamat Kontak', 'type' => 'textarea', 'value' => ['value' => 'Jl. Kebaikan No. 8, Jakarta Selatan']],
            ['group' => 'contact', 'key' => 'contact_hours', 'label' => 'Jam Layanan', 'type' => 'text', 'value' => ['value' => 'Senin - Jumat, 09.00 - 17.00 WIB']],
            ['group' => 'payment', 'key' => 'payment_bank', 'label' => 'Bank Transfer Donasi', 'type' => 'text', 'value' => ['value' => 'BSI']],
            ['group' => 'payment', 'key' => 'payment_account_number', 'label' => 'Nomor Rekening Donasi', 'type' => 'text', 'value' => ['value' => '7063488245']],
            ['group' => 'payment', 'key' => 'payment_account_name', 'label' => 'Atas Nama Rekening Donasi', 'type' => 'text', 'value' => ['value' => 'Yayasan Riyadhush Sholihin Tegal']],
            ['group' => 'social', 'key' => 'social_facebook', 'label' => 'Facebook', 'type' => 'url', 'value' => ['value' => 'https://facebook.com']],
            ['group' => 'social', 'key' => 'social_twitter', 'label' => 'Twitter/X', 'type' => 'url', 'value' => ['value' => 'https://x.com']],
            ['group' => 'social', 'key' => 'social_instagram', 'label' => 'Instagram', 'type' => 'url', 'value' => ['value' => 'https://instagram.com']],
            ['group' => 'social', 'key' => 'social_telegram', 'label' => 'Telegram', 'type' => 'url', 'value' => ['value' => 'https://t.me']],
            ['group' => 'footer', 'key' => 'footer_description', 'label' => 'Deskripsi Footer', 'type' => 'textarea', 'value' => ['value' => 'Platform donasi berbasis campaign dengan pengelolaan konten yang rapi, transparan, dan mudah diperbarui dari CMS admin.']],
            ['group' => 'footer', 'key' => 'footer_copyright', 'label' => 'Copyright Footer', 'type' => 'text', 'value' => ['value' => 'Copyright 2026 Donasi Harapan. Semua hak dilindungi.']],
            ['group' => 'footer', 'key' => 'footer_primary_cta_label', 'label' => 'Label CTA Footer', 'type' => 'text', 'value' => ['value' => 'Cek Status Donasi']],
            ['group' => 'footer', 'key' => 'footer_primary_cta_url', 'label' => 'URL CTA Footer', 'type' => 'text', 'value' => ['value' => '/donation/check']],
            ['group' => 'footer', 'key' => 'footer_navigation_menu', 'label' => 'Menu Footer Utama', 'type' => 'json', 'value' => [['label' => 'Campaign', 'url' => '/campaign'], ['label' => 'Tentang', 'url' => '/pages/about'], ['label' => 'Kontak', 'url' => '/pages/contact']]],
            ['group' => 'footer', 'key' => 'footer_support_menu', 'label' => 'Menu Footer Bantuan', 'type' => 'json', 'value' => [['label' => 'FAQ', 'url' => '/pages/faq'], ['label' => 'Tentang', 'url' => '/pages/about'], ['label' => 'Kebijakan Privasi', 'url' => '/pages/privacy-policy']]],
        ];

        foreach ($settings as $setting) {
            Setting::query()->updateOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }
    }

    private function seedCategories(): array
    {
        $categories = [
            'education' => [
                'name' => 'Education',
                'slug' => 'education',
                'description' => 'Program pendidikan, zakat produktif, dan penguatan kapasitas keluarga.',
                'sort_order' => 1,
                'is_active' => true,
            ],
            'humanity' => [
                'name' => 'Humanity',
                'slug' => 'humanity',
                'description' => 'Program kemanusiaan, bantuan sosial, kesehatan, dan distribusi lapangan.',
                'sort_order' => 2,
                'is_active' => true,
            ],
        ];

        $result = [];

        foreach ($categories as $key => $payload) {
            $result[$key] = CampaignCategory::query()->updateOrCreate(
                ['slug' => $payload['slug']],
                $payload
            );
        }

        return $result;
    }

    private function seedCampaigns(array $categories): array
    {
        $campaigns = [
            'pangan-pekanan' => [
                'campaign_category_id' => $categories['education']->id,
                'title' => 'Paket Pangan Pekanan',
                'slug' => 'pangan-pekanan',
                'organizer_name' => 'Yayasan Peduli Harapan',
                'featured_badge' => 'Pangan Pekanan',
                'cta_label' => 'Donasi Sekarang',
                'location' => 'Jakarta Timur dan Bekasi',
                'focus_area' => 'Paket bahan pokok',
                'distribution_plan' => 'Setiap pekan',
                'summary' => 'Distribusi paket pangan rutin untuk keluarga prasejahtera di wilayah padat perkotaan.',
                'content' => "Banyak keluarga bertahan dengan pengeluaran yang sangat terbatas untuk kebutuhan pokok setiap pekan.\n\nCampaign ini membantu menjaga ketersediaan bahan pangan dasar sekaligus membuka ruang pendampingan yang lebih berkelanjutan.",
                'target_amount' => 150000000,
                'current_amount' => 0,
                'donor_count' => 0,
                'start_date' => now()->subDays(12)->toDateString(),
                'end_date' => now()->addDays(25)->toDateString(),
                'publish_status' => 'published',
                'public_status' => 'active',
                'is_featured' => true,
                'display_order' => 1,
                'meta' => null,
            ],
            'jariyah-air' => [
                'campaign_category_id' => $categories['humanity']->id,
                'title' => 'Jariyah Infrastruktur Air',
                'slug' => 'jariyah-air',
                'organizer_name' => 'Yayasan Peduli Harapan',
                'featured_badge' => 'Jariyah Air',
                'cta_label' => 'Donasi Sekarang',
                'location' => 'Lombok Timur',
                'focus_area' => 'Akses air bersih',
                'distribution_plan' => 'Per tahap konstruksi',
                'summary' => 'Pembangunan instalasi air bersih sederhana untuk komunitas yang kesulitan akses air layak.',
                'content' => "Air bersih masih menjadi kebutuhan paling mendasar yang belum merata di banyak wilayah.\n\nMelalui campaign ini, bantuan diarahkan pada infrastruktur kecil yang langsung dapat digunakan masyarakat.",
                'target_amount' => 240000000,
                'current_amount' => 0,
                'donor_count' => 0,
                'start_date' => now()->subDays(25)->toDateString(),
                'end_date' => now()->addDays(58)->toDateString(),
                'publish_status' => 'published',
                'public_status' => 'active',
                'is_featured' => true,
                'display_order' => 2,
                'meta' => null,
            ],
            'teman-pulih' => [
                'campaign_category_id' => $categories['humanity']->id,
                'title' => 'Teman Pulih Pasien Dhuafa',
                'slug' => 'teman-pulih',
                'organizer_name' => 'Yayasan Peduli Harapan',
                'featured_badge' => 'Teman Pulih',
                'cta_label' => 'Donasi Sekarang',
                'location' => 'Jabodetabek',
                'focus_area' => 'Pendampingan pasien',
                'distribution_plan' => 'Sesuai kasus',
                'summary' => 'Bantuan transport, nutrisi, dan kebutuhan pendamping pasien dhuafa selama masa pemulihan.',
                'content' => "Biaya pengobatan sering kali bukan satu-satunya tantangan bagi pasien dari keluarga prasejahtera.\n\nCampaign ini hadir untuk menopang kebutuhan-kebutuhan kecil yang justru sangat menentukan proses pemulihan.",
                'target_amount' => 138000000,
                'current_amount' => 0,
                'donor_count' => 0,
                'start_date' => now()->subDays(5)->toDateString(),
                'end_date' => now()->addDays(35)->toDateString(),
                'publish_status' => 'published',
                'public_status' => 'active',
                'is_featured' => false,
                'display_order' => 3,
                'meta' => null,
            ],
            'ibu-hebat' => [
                'campaign_category_id' => $categories['humanity']->id,
                'title' => 'Ruang Tumbuh Ibu Hebat',
                'slug' => 'ibu-hebat',
                'organizer_name' => 'Yayasan Peduli Harapan',
                'featured_badge' => 'Ibu Hebat',
                'cta_label' => 'Donasi Sekarang',
                'location' => 'Cianjur',
                'focus_area' => 'Ibu dan keluarga rentan',
                'distribution_plan' => 'Per kelompok dampingan',
                'summary' => 'Program dukungan psikososial dan ekonomi mikro bagi ibu-ibu dalam kondisi rentan.',
                'content' => "Banyak ibu memikul beban rumah tangga sekaligus tekanan ekonomi tanpa ruang dukungan yang memadai.\n\nProgram ini memadukan bantuan dasar, kelas penguatan, dan jaringan dukungan komunitas.",
                'target_amount' => 140000000,
                'current_amount' => 0,
                'donor_count' => 0,
                'start_date' => now()->subDays(8)->toDateString(),
                'end_date' => now()->addDays(17)->toDateString(),
                'publish_status' => 'published',
                'public_status' => 'active',
                'is_featured' => false,
                'display_order' => 4,
                'meta' => null,
            ],
            'ibu-mandiri' => [
                'campaign_category_id' => $categories['education']->id,
                'title' => 'Ibu Mandiri Berdaya',
                'slug' => 'ibu-mandiri',
                'organizer_name' => 'Yayasan Peduli Harapan',
                'featured_badge' => 'Ibu Mandiri',
                'cta_label' => 'Lihat Detail',
                'location' => 'Tasikmalaya',
                'focus_area' => 'Pemberdayaan ibu',
                'distribution_plan' => 'Selesai',
                'summary' => 'Program pemberdayaan ibu yang telah selesai dan siap ditampilkan sebagai arsip campaign.',
                'content' => 'Program ini menjadi contoh campaign selesai yang tetap perlu tampil di publik untuk menjaga kontinuitas cerita dampak.',
                'target_amount' => 69320000,
                'current_amount' => 69320000,
                'donor_count' => 0,
                'start_date' => now()->subDays(120)->toDateString(),
                'end_date' => now()->subDays(62)->toDateString(),
                'publish_status' => 'published',
                'public_status' => 'completed',
                'is_featured' => false,
                'display_order' => 5,
                'meta' => null,
            ],
        ];

        $result = [];

        foreach ($campaigns as $slug => $payload) {
            $result[$slug] = Campaign::query()->updateOrCreate(
                ['slug' => $payload['slug']],
                $payload
            );
        }

        return $result;
    }

    private function seedCampaignUpdates(array $campaigns): void
    {
        $updates = [
            [
                'campaign' => 'pangan-pekanan',
                'title' => 'Distribusi tahap awal dimulai',
                'excerpt' => 'Tim lapangan menyiapkan distribusi paket pangan untuk keluarga penerima tahap pertama.',
                'content' => 'Tim lapangan mulai melakukan penyiapan kebutuhan untuk campaign Paket Pangan Pekanan dan memastikan data penerima manfaat tetap terverifikasi.',
                'is_published' => true,
                'published_at' => now()->subDays(4),
            ],
            [
                'campaign' => 'jariyah-air',
                'title' => 'Survey titik air bersih selesai',
                'excerpt' => 'Tim teknis telah menyelesaikan survey lapangan untuk titik penyaluran tahap awal.',
                'content' => 'Survey lapangan dan verifikasi kebutuhan komunitas telah selesai. Tahap berikutnya masuk ke pengadaan material dan penjadwalan pengerjaan.',
                'is_published' => true,
                'published_at' => now()->subDays(7),
            ],
            [
                'campaign' => 'teman-pulih',
                'title' => 'Pendampingan pasien batch pertama',
                'excerpt' => 'Bantuan transport dan nutrisi mulai disalurkan ke pasien dhuafa yang didampingi.',
                'content' => 'Program pendampingan batch pertama sudah berjalan, termasuk dukungan transport kontrol dan nutrisi selama masa pemulihan.',
                'is_published' => true,
                'published_at' => now()->subDays(2),
            ],
        ];

        foreach ($updates as $update) {
            CampaignUpdate::query()->updateOrCreate(
                [
                    'campaign_id' => $campaigns[$update['campaign']]->id,
                    'title' => $update['title'],
                ],
                [
                    'excerpt' => $update['excerpt'],
                    'content' => $update['content'],
                    'featured_image' => null,
                    'is_published' => $update['is_published'],
                    'published_at' => $update['published_at'],
                ]
            );
        }
    }

    private function seedHeroBanners(array $campaigns): void
    {
        $banners = [
            [
                'campaign' => 'pangan-pekanan',
                'title' => 'Paket Pangan Pekanan',
                'eyebrow' => 'Program unggulan',
                'subtitle' => 'Bantu keluarga prasejahtera mendapatkan bahan pokok rutin dengan alur distribusi yang terukur.',
                'cta_label' => 'Lihat Program',
                'sort_order' => 1,
            ],
            [
                'campaign' => 'jariyah-air',
                'title' => 'Jariyah Infrastruktur Air',
                'eyebrow' => 'Program kemanusiaan',
                'subtitle' => 'Bangun akses air bersih yang lebih layak untuk komunitas yang selama ini kesulitan sumber air aman.',
                'cta_label' => 'Buka Campaign',
                'sort_order' => 2,
            ],
            [
                'campaign' => 'teman-pulih',
                'title' => 'Teman Pulih Pasien Dhuafa',
                'eyebrow' => 'Program kesehatan',
                'subtitle' => 'Dampingi pasien dhuafa melalui dukungan transport, nutrisi, dan kebutuhan pemulihan lainnya.',
                'cta_label' => 'Lihat Detail',
                'sort_order' => 3,
            ],
        ];

        foreach ($banners as $banner) {
            HeroBanner::query()->updateOrCreate(
                ['title' => $banner['title']],
                [
                    'campaign_id' => $campaigns[$banner['campaign']]->id,
                    'eyebrow' => $banner['eyebrow'],
                    'subtitle' => $banner['subtitle'],
                    'image_path' => null,
                    'cta_label' => $banner['cta_label'],
                    'cta_url' => null,
                    'is_active' => true,
                    'sort_order' => $banner['sort_order'],
                ]
            );
        }
    }

    private function seedStaticPages(): void
    {
        $pages = [
            [
                'slug' => 'about',
                'title' => 'Tentang Donasi Harapan',
                'intro' => 'Platform donasi berbasis campaign yang dirancang untuk alur publik yang jelas dan pengelolaan konten yang rapi.',
                'content' => "Donasi Harapan menghubungkan orang baik dengan program sosial yang dikelola secara terstruktur.\n\nSetiap campaign dapat diperbarui melalui CMS agar publik melihat progres yang relevan dan mudah dipahami.\n\nKami fokus pada kejelasan informasi, keteraturan operasional, dan pengalaman berdonasi yang hangat.",
            ],
            [
                'slug' => 'contact',
                'title' => 'Kontak dan Bantuan',
                'intro' => 'Hubungi tim kami untuk bantuan program, kerja sama, atau pertanyaan umum seputar campaign.',
                'content' => "Email: halo@donasiharapan.test\n\nWhatsApp: 0812-0000-0000\n\nJam layanan: Senin sampai Jumat, 09.00 - 17.00 WIB",
            ],
            [
                'slug' => 'faq',
                'title' => 'Pertanyaan yang Sering Ditanyakan',
                'intro' => 'Jawaban cepat untuk pertanyaan umum sebelum Anda mendukung campaign.',
                'content' => "Bagaimana memilih campaign? Anda dapat menggunakan filter status dan kategori pada halaman campaign.\n\nApakah bisa berdonasi anonim? Ya, donor dapat tampil anonim di publik.\n\nApakah campaign selesai tetap ditampilkan? Ya, campaign selesai tetap tampil sebagai arsip dampak.",
            ],
            [
                'slug' => 'privacy-policy',
                'title' => 'Kebijakan Privasi',
                'intro' => 'Penjelasan tentang data yang dikumpulkan, cara penggunaan, dan visibilitasnya di area publik.',
                'content' => "Kami mengumpulkan data dasar seperti nama, email, nomor telepon, dan data transaksi ketika donasi dilakukan.\n\nData digunakan untuk keperluan operasional platform, komunikasi program, dan pencatatan donasi.\n\nData donor hanya ditampilkan di publik jika memenuhi aturan visibilitas yang berlaku.",
            ],
        ];

        foreach ($pages as $page) {
            StaticPage::query()->updateOrCreate(
                ['slug' => $page['slug']],
                [
                    'title' => $page['title'],
                    'intro' => $page['intro'],
                    'content' => $page['content'],
                    'seo_title' => $page['title'],
                    'seo_description' => $page['intro'],
                    'is_published' => true,
                    'published_at' => now(),
                ]
            );
        }

        StaticPage::query()->where('slug', 'hak-donatur')->delete();
    }

    private function seedFaqItems(): void
    {
        $items = [
            [
                'question' => 'Bagaimana memilih campaign yang tepat untuk didukung?',
                'answer' => 'Anda dapat memilih campaign berdasarkan kategori, status, lokasi, serta ringkasan tujuan program pada halaman campaign publik.',
                'sort_order' => 1,
                'is_active' => true,
            ],
            [
                'question' => 'Apakah donor bisa tampil anonim di website?',
                'answer' => 'Bisa. Saat mengisi data donasi, donor dapat memilih tampil anonim pada area publik.',
                'sort_order' => 2,
                'is_active' => true,
            ],
            [
                'question' => 'Apakah campaign yang sudah selesai tetap ditampilkan?',
                'answer' => 'Ya. Campaign yang selesai tetap dapat ditampilkan sebagai arsip dampak dan dokumentasi program.',
                'sort_order' => 3,
                'is_active' => true,
            ],
        ];

        foreach ($items as $item) {
            FaqItem::query()->updateOrCreate(
                ['question' => $item['question']],
                $item
            );
        }
    }

    private function seedTestimonials(): void
    {
        $items = [
            [
                'name' => 'Rahmawati',
                'role' => 'Donatur Rutin',
                'location' => 'Bekasi',
                'quote' => 'Saya suka karena informasi campaign dan progresnya jelas. Admin juga bisa memperbarui konten dengan cepat, jadi kami merasa lebih yakin saat berdonasi.',
                'rating' => 5,
                'sort_order' => 1,
                'is_active' => true,
            ],
            [
                'name' => 'Budi Prasetyo',
                'role' => 'Relawan Lapangan',
                'location' => 'Jakarta',
                'quote' => 'Cerita program di website terasa hidup dan mudah dipahami. Update dari tim admin membuat publik bisa melihat perkembangan program dengan rapi.',
                'rating' => 5,
                'sort_order' => 2,
                'is_active' => true,
            ],
            [
                'name' => 'Naila Putri',
                'role' => 'Donatur Komunitas',
                'location' => 'Bandung',
                'quote' => 'Alur donasinya sederhana dan halaman FAQ membantu menjawab pertanyaan dasar tanpa perlu bingung mencari informasi ke tempat lain.',
                'rating' => 5,
                'sort_order' => 3,
                'is_active' => true,
            ],
        ];

        foreach ($items as $item) {
            Testimonial::query()->updateOrCreate(
                ['name' => $item['name'], 'quote' => $item['quote']],
                $item
            );
        }
    }

    private function seedDonorsAndDonations(array $campaigns): void
    {
        $donors = [
            'rahmawati@example.com' => ['name' => 'Rahmawati', 'email' => 'rahmawati@example.com', 'phone' => '081211110001'],
            'budi@example.com' => ['name' => 'Budi Prasetyo', 'email' => 'budi@example.com', 'phone' => '081211110002'],
            'naila@example.com' => ['name' => 'Naila Putri', 'email' => 'naila@example.com', 'phone' => '081211110003'],
            'fajar@example.com' => ['name' => 'Fajar Nugraha', 'email' => 'fajar@example.com', 'phone' => '081211110004'],
        ];

        $donorModels = [];

        foreach ($donors as $key => $payload) {
            $donorModels[$key] = Donor::query()->updateOrCreate(
                ['email' => $payload['email']],
                $payload
            );
        }

        $donations = [
            ['reference' => 'INV-DEMO-001', 'campaign' => 'pangan-pekanan', 'donor' => 'rahmawati@example.com', 'amount' => 250000, 'is_anonymous' => false, 'show_on_public' => true, 'paid_at' => now()->subHours(2)],
            ['reference' => 'INV-DEMO-002', 'campaign' => 'pangan-pekanan', 'donor' => 'budi@example.com', 'amount' => 500000, 'is_anonymous' => true, 'show_on_public' => true, 'paid_at' => now()->subHours(10)],
            ['reference' => 'INV-DEMO-003', 'campaign' => 'jariyah-air', 'donor' => 'naila@example.com', 'amount' => 1500000, 'is_anonymous' => false, 'show_on_public' => true, 'paid_at' => now()->subDays(1)],
            ['reference' => 'INV-DEMO-004', 'campaign' => 'jariyah-air', 'donor' => 'fajar@example.com', 'amount' => 2500000, 'is_anonymous' => true, 'show_on_public' => true, 'paid_at' => now()->subDays(2)],
            ['reference' => 'INV-DEMO-005', 'campaign' => 'teman-pulih', 'donor' => 'rahmawati@example.com', 'amount' => 350000, 'is_anonymous' => false, 'show_on_public' => true, 'paid_at' => now()->subHours(5)],
            ['reference' => 'INV-DEMO-006', 'campaign' => 'ibu-hebat', 'donor' => 'budi@example.com', 'amount' => 275000, 'is_anonymous' => false, 'show_on_public' => true, 'paid_at' => now()->subDays(3)],
            ['reference' => 'INV-DEMO-007', 'campaign' => 'ibu-mandiri', 'donor' => 'naila@example.com', 'amount' => 69320000, 'is_anonymous' => false, 'show_on_public' => true, 'paid_at' => now()->subDays(80)],
        ];

        foreach ($donations as $donation) {
            $donor = $donorModels[$donation['donor']];

            Donation::query()->updateOrCreate(
                ['reference' => $donation['reference']],
                [
                    'campaign_id' => $campaigns[$donation['campaign']]->id,
                    'donor_id' => $donor->id,
                    'donor_name' => $donor->name,
                    'donor_email' => $donor->email,
                    'donor_phone' => $donor->phone,
                    'amount' => $donation['amount'],
                    'base_amount' => $donation['amount'],
                    'unique_code' => 0,
                    'prayer_message' => 'Semoga program ini membawa manfaat luas.',
                    'is_anonymous' => $donation['is_anonymous'],
                    'show_on_public' => $donation['show_on_public'],
                    'status' => 'paid',
                    'paid_at' => $donation['paid_at'],
                    'expires_at' => null,
                    'metadata' => ['seeded' => true],
                    'payment_bank' => 'BSI',
                    'payment_account_number' => '7063488245',
                    'payment_account_name' => 'Yayasan Riyadhush Sholihin Tegal',
                    'verified_at' => $donation['paid_at'],
                ]
            );
        }
    }

    private function refreshCampaignStats(array $campaigns): void
    {
        foreach ($campaigns as $campaign) {
            $paidDonations = Donation::query()
                ->where('campaign_id', $campaign->id)
                ->where('status', 'paid');

            $campaign->update([
                'current_amount' => (float) $paidDonations->sum('amount'),
                'donor_count' => (int) $paidDonations->count(),
            ]);
        }
    }
}

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e($site['title'] ?? config('app.name')); ?></title>
        <meta name="description" content="<?php echo e($site['description'] ?? ''); ?>">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=oswald:400,500,600,700|instrument-sans:400,500,600,700" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body>
        <div class="flex min-h-screen flex-col bg-[radial-gradient(circle_at_top_left,rgba(15,92,168,0.08),transparent_24%),linear-gradient(180deg,#eff4f8_0%,#edf2f6_100%)] py-6">
            <?php echo $__env->make('layouts.partials.public-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="mt-4 flex-1">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <?php echo $__env->make('layouts.partials.public-footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH F:\coding\ic\donasi-test-private\resources\views/layouts/public.blade.php ENDPATH**/ ?>
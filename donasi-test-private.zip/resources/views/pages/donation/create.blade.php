@extends('layouts.public')

@section('content')
    <div class="mx-auto w-[min(1120px,calc(100%-1rem))] space-y-5">
        <section class="rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-5 py-6 text-white shadow-[0_18px_40px_rgba(18,52,87,0.16)] sm:rounded-[30px] sm:px-8 sm:py-8">
            <p class="text-[11px] uppercase tracking-[0.28em] text-blue-100">Checkout Donasi</p>
            <h1 class="mt-3 font-display text-[2.45rem] leading-none sm:text-[3.2rem]">Dukung {{ $campaign->title }}</h1>
            <p class="mt-4 max-w-3xl text-sm leading-7 text-blue-50/90">
                Setelah form dikirim, sistem akan membuat nomor referensi dan nominal transfer unik agar admin lebih mudah mencocokkan dana masuk di mutasi rekening.
            </p>
        </section>

        <section class="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
            <aside class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Ringkasan Campaign</p>
                <h2 class="mt-2 font-display text-[2rem] leading-none text-[#123457]">{{ $campaign->title }}</h2>
                <p class="mt-4 text-sm leading-7 text-[#31465d]">{{ $campaign->summary }}</p>

                <div class="mt-5 grid gap-3">
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Terkumpul</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">Rp {{ number_format((float) $campaign->current_amount, 0, ',', '.') }}</p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Target</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">Rp {{ number_format((float) $campaign->target_amount, 0, ',', '.') }}</p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Pengelola</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">{{ $campaign->organizer_name }}</p>
                    </div>
                </div>
            </aside>

            <form method="POST" action="{{ route('donation.store', $campaign->slug) }}" data-dirty-form class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                @csrf

                <div class="mb-5 rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] px-4 py-4 text-sm leading-7 text-[#31465d]">
                    <p class="font-semibold text-[#123457]">Alur transfer rekening</p>
                    <p class="mt-2">Isi data donasi, transfer sesuai total unik yang muncul, lalu kirim konfirmasi sederhana ke WhatsApp admin dari halaman status.</p>
                    <a href="{{ route('donation.lookup') }}" class="mt-3 inline-flex rounded-full bg-pm-blue px-4 py-2 text-xs font-semibold text-white">
                        Cek Status Donasi
                    </a>
                </div>

                <div class="grid gap-5 lg:grid-cols-2">
                    <label class="block lg:col-span-2">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nominal Donasi</span>
                        <input type="text" name="amount" inputmode="numeric" value="{{ old('amount') }}" data-money-input class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" placeholder="Contoh: 100000">
                        @error('amount') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                    </label>

                    <label class="block">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nama</span>
                        <input type="text" name="donor_name" value="{{ old('donor_name') }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" required>
                        @error('donor_name') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                    </label>

                    <label class="block">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Nomor WhatsApp / HP</span>
                        <input type="text" name="donor_phone" value="{{ old('donor_phone') }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" required>
                        @error('donor_phone') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                    </label>

                    <label class="block lg:col-span-2">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Email</span>
                        <input type="email" name="donor_email" value="{{ old('donor_email') }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                        @error('donor_email') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                    </label>

                    <label class="block lg:col-span-2">
                        <span class="mb-2 block text-sm font-medium text-[#23405f]">Doa / Pesan</span>
                        <textarea name="prayer_message" rows="5" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">{{ old('prayer_message') }}</textarea>
                    </label>

                    <label class="flex items-center gap-3 rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm font-medium text-[#23405f] lg:col-span-2">
                        <input type="hidden" name="is_anonymous" value="0">
                        <input type="checkbox" name="is_anonymous" value="1" @checked(old('is_anonymous')) class="h-4 w-4 rounded border-[#b8c8d8] text-pm-blue focus:ring-pm-blue">
                        Tampilkan sebagai anonim di halaman publik
                    </label>
                </div>

                <div class="mt-6 flex flex-wrap justify-end gap-3">
                    <a href="{{ route('campaign.show', $campaign->slug) }}" class="rounded-full border border-[#dce6f1] px-5 py-3 text-sm font-medium text-[#23405f]">Kembali</a>
                    <button type="submit" class="rounded-full bg-pm-blue px-5 py-3 text-sm font-semibold text-white">Lanjut ke Instruksi Transfer</button>
                </div>
            </form>
        </section>
    </div>
@endsection

@extends('layouts.admin')

@section('content')
    <form method="POST" action="{{ $category->exists ? route('admin.categories.update', $category) : route('admin.categories.store') }}" data-dirty-form class="space-y-6">
        @csrf
        @if ($category->exists)
            @method('PUT')
        @endif

        <section class="rounded-[26px] bg-white shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
            <div class="grid gap-5 px-5 py-5 lg:grid-cols-2">
                <label class="block">
                    <span class="mb-2 block text-sm font-medium text-[#23405f]">Nama Kategori</span>
                    <input type="text" name="name" value="{{ old('name', $category->name) }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" required>
                    @error('name') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                </label>

                <label class="block">
                    <span class="mb-2 block text-sm font-medium text-[#23405f]">Slug</span>
                    <input type="text" name="slug" value="{{ old('slug', $category->slug) }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                    @error('slug') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                </label>

                <label class="block lg:col-span-2">
                    <span class="mb-2 block text-sm font-medium text-[#23405f]">Deskripsi</span>
                    <textarea name="description" rows="5" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">{{ old('description', $category->description) }}</textarea>
                    @error('description') <span class="mt-2 block text-xs text-[#b42318]">{{ $message }}</span> @enderror
                </label>

                <label class="block">
                    <span class="mb-2 block text-sm font-medium text-[#23405f]">Urutan</span>
                    <input type="number" min="0" name="sort_order" value="{{ old('sort_order', $category->sort_order ?? 0) }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                </label>

                <label class="flex items-center gap-3 rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm font-medium text-[#23405f]">
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $category->is_active)) class="h-4 w-4 rounded border-[#b8c8d8] text-pm-blue focus:ring-pm-blue">
                    Kategori aktif
                </label>
            </div>

            <div class="flex flex-wrap justify-end gap-3 border-t border-[#e4edf6] px-5 py-4">
                <a href="{{ route('admin.categories') }}" class="rounded-full border border-[#dce6f1] px-5 py-3 text-sm font-medium text-[#23405f]">Batal</a>
                <button type="submit" class="rounded-full bg-pm-blue px-5 py-3 text-sm font-semibold text-white">Simpan</button>
            </div>
        </section>
    </form>
@endsection

<?php $__env->startSection('content'); ?>
    <?php
        $statusMeta = [
            'pending' => ['label' => 'Menunggu Transfer', 'class' => 'bg-[#fff4da] text-[#9a6700]'],
            'paid' => ['label' => 'Donasi Diterima', 'class' => 'bg-[#e8f8ef] text-[#18794e]'],
            'failed' => ['label' => 'Verifikasi Gagal', 'class' => 'bg-[#fff1f1] text-[#b42318]'],
            'expired' => ['label' => 'Kedaluwarsa', 'class' => 'bg-[#eef2f6] text-[#56708e]'],
            'refunded' => ['label' => 'Dikembalikan', 'class' => 'bg-[#eef5ff] text-pm-blue'],
        ][$donation->status] ?? ['label' => str($donation->status)->headline(), 'class' => 'bg-[#eef5ff] text-pm-blue'];
    ?>

    <div class="mx-auto w-[min(980px,calc(100%-1rem))] space-y-5">
        <section class="rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-5 py-6 text-white shadow-[0_18px_40px_rgba(18,52,87,0.16)] sm:rounded-[30px] sm:px-8 sm:py-8">
            <p class="text-[11px] uppercase tracking-[0.28em] text-blue-100">Status Donasi</p>
            <h1 class="mt-3 font-display text-[2.45rem] leading-none sm:text-[3.2rem]"><?php echo e($donation->reference); ?></h1>
            <p class="mt-4 max-w-3xl text-sm leading-7 text-blue-50/90">
                Donasi Anda sudah tercatat. Silakan transfer sesuai total unik agar admin mudah mencocokkan dana masuk di mutasi rekening.
            </p>
            <div class="mt-5 flex flex-wrap gap-3">
                <button
                    type="button"
                    data-copy-text="<?php echo e($donation->reference); ?>"
                    class="rounded-full bg-white px-4 py-2 text-sm font-semibold text-pm-blue transition hover:bg-blue-50"
                >
                    Salin Nomor Referensi
                </button>
                <button
                    type="button"
                    data-copy-text="<?php echo e(route('donation.show', $donation->reference)); ?>"
                    class="rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/15"
                >
                    Salin Link Status
                </button>
            </div>
            <p class="mt-3 text-xs text-blue-100/90">Simpan salah satu di atas agar Anda bisa mengecek status donasi lagi tanpa login.</p>
        </section>

        <section class="grid gap-5 lg:grid-cols-[1.05fr_0.95fr]">
            <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Ringkasan Donasi</p>
                <div class="mt-4 grid gap-3">
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Campaign</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($donation->campaign?->title ?? '-'); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Nominal Donasi</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">Rp <?php echo e(number_format((float) ($donation->base_amount ?: $donation->amount), 0, ',', '.')); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Kode Unik Verifikasi</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">Rp <?php echo e(number_format((int) $donation->unique_code, 0, ',', '.')); ?></p>
                        <p class="mt-2 text-xs leading-5 text-[#56708e]">Tambahan angka ini masuk sebagai bagian dari donasi dan membantu admin menemukan transfer Anda di mutasi rekening.</p>
                    </div>
                    <div class="rounded-2xl border border-[#c7d9ed] bg-[#f8fbff] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Total Yang Harus Ditransfer</p>
                        <p class="mt-2 text-2xl font-semibold text-[#123457]">Rp <?php echo e(number_format((float) $donation->amount, 0, ',', '.')); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Status</p>
                        <p class="mt-2 inline-flex rounded-full px-3 py-1 text-sm font-semibold <?php echo e($statusMeta['class']); ?>"><?php echo e($statusMeta['label']); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Dibuat</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e(optional($donation->created_at)->translatedFormat('d F Y, H:i')); ?></p>
                    </div>
                    <div class="rounded-2xl border border-[#e6edf6] px-4 py-3">
                        <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Batas Status Pending</p>
                        <p class="mt-2 text-lg font-semibold text-[#123457]">
                            <?php echo e($donation->expires_at ? $donation->expires_at->translatedFormat('d F Y, H:i') : 'Belum ditentukan'); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="space-y-5">
                <div class="rounded-[24px] border border-[#d6e4f1] bg-[#f8fbff] px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.05)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Rekening Tujuan</p>
                    <div class="mt-4 grid gap-3">
                        <div class="rounded-2xl border border-[#e6edf6] bg-white px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Bank</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($donation->payment_bank ?: 'BSI'); ?></p>
                        </div>
                        <div class="rounded-2xl border border-[#e6edf6] bg-white px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Nomor Rekening</p>
                            <div class="mt-2 flex flex-wrap items-center gap-2">
                                <p class="font-mono text-lg font-semibold text-[#123457]"><?php echo e($donation->payment_account_number ?: '-'); ?></p>
                                <?php if($donation->payment_account_number): ?>
                                    <button type="button" data-copy-text="<?php echo e($donation->payment_account_number); ?>" class="rounded-full border border-[#dce6f1] px-3 py-1 text-xs font-semibold text-[#23405f]">Salin</button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="rounded-2xl border border-[#e6edf6] bg-white px-4 py-3">
                            <p class="text-[10px] uppercase tracking-[0.14em] text-pm-muted">Atas Nama</p>
                            <p class="mt-2 text-lg font-semibold text-[#123457]"><?php echo e($donation->payment_account_name ?: '-'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="rounded-[24px] bg-white px-4 py-5 shadow-[0_16px_34px_rgba(14,44,82,0.08)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Setelah Transfer</p>
                    <div class="mt-4 space-y-3 text-sm leading-7 text-[#31465d]">
                        <?php if($donation->status === 'paid'): ?>
                            <p><strong>Terima kasih.</strong> Donasi Anda sudah diterima dan diverifikasi admin.</p>
                            <p>Waktu verifikasi: <?php echo e($donation->verified_at ? $donation->verified_at->translatedFormat('d F Y, H:i') : optional($donation->paid_at)->translatedFormat('d F Y, H:i')); ?>.</p>
                        <?php elseif($donation->status === 'expired'): ?>
                            <p>Donasi ini sudah melewati batas transfer. Silakan buat donasi baru jika masih ingin mendukung campaign ini.</p>
                        <?php elseif($donation->status === 'failed'): ?>
                            <p>Verifikasi donasi ini belum berhasil. Silakan hubungi admin dengan nomor referensi di atas.</p>
                        <?php else: ?>
                            <p>Transfer tepat sebesar <strong>Rp <?php echo e(number_format((float) $donation->amount, 0, ',', '.')); ?></strong> sebelum batas waktu pending.</p>
                            <p>Setelah transfer, kirim konfirmasi singkat ke WhatsApp admin. Admin akan mengecek mutasi rekening dan mengubah status menjadi <strong>Donasi Diterima</strong> setelah dana masuk.</p>
                            <?php if($whatsAppUrl): ?>
                                <a href="<?php echo e($whatsAppUrl); ?>" target="_blank" rel="noopener" class="inline-flex rounded-full bg-[#18794e] px-4 py-2 text-sm font-semibold text-white">Konfirmasi via WhatsApp</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="rounded-[24px] bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-4 py-5 text-white shadow-[0_16px_34px_rgba(14,44,82,0.12)] sm:rounded-[28px] sm:px-5 sm:py-6">
                    <p class="text-[10px] uppercase tracking-[0.18em] text-blue-100">Aksi Berikutnya</p>
                    <div class="mt-4 flex flex-wrap gap-3">
                        <a href="<?php echo e(route('donation.invoice', $donation->reference)); ?>" class="rounded-full bg-white px-4 py-2 text-sm font-semibold text-pm-blue">
                            Download <?php echo e($donation->status === 'paid' ? 'Kuitansi' : 'Tagihan'); ?> (PDF)
                        </a>
                        <a href="<?php echo e(route('campaign.show', $donation->campaign?->slug ?? '')); ?>" class="rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold text-white">Kembali ke Campaign</a>
                        <a href="<?php echo e(route('donation.lookup', ['reference' => $donation->reference])); ?>" class="rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold text-white">Buka via Cek Status</a>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\coding\donasi-test-private\resources\views/pages/donation/show.blade.php ENDPATH**/ ?>
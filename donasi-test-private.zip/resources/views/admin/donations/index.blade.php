@extends('layouts.admin')

@section('content')
    <section class="rounded-[26px] bg-white shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
        <div class="border-b border-[#e4edf6] px-5 py-5">
            <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Modul Administrasi</p>
            <h2 class="mt-1 font-display text-3xl leading-none text-[#123457]">{{ $page['title'] }}</h2>
            <p class="mt-3 max-w-3xl text-sm leading-7 text-[#56708e]">{{ $page['description'] }}</p>
        </div>

        <div class="grid gap-4 border-b border-[#e4edf6] px-5 py-5 lg:grid-cols-[1fr_1fr]">
            <div class="rounded-2xl border border-[#d6e4f1] bg-[#f8fbff] px-4 py-4 text-sm leading-7 text-[#31465d]">
                <p class="font-semibold text-[#123457]">Alur verifikasi transfer manual</p>
                <p class="mt-2">Cek mutasi BSI, cari nominal masuk yang sama dengan total transfer, cocokkan dengan referensi di tabel, lalu klik status dan isi catatan bila perlu.</p>
            </div>

            <form method="GET" action="{{ route('admin.donations') }}" class="grid gap-3 rounded-2xl border border-[#e4edf6] bg-white px-4 py-4 sm:grid-cols-[1fr_140px_140px_120px_auto]">
                <label class="block">
                    <span class="mb-2 block text-xs font-semibold text-[#56708e]">Pencarian</span>
                    <input type="text" name="q" value="{{ $filters['q'] ?? '' }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue" placeholder="Referensi, donor...">
                </label>
                <label class="block">
                    <span class="mb-2 block text-xs font-semibold text-[#56708e]">Mulai Tanggal</span>
                    <input type="date" name="start_date" value="{{ $filters['start_date'] ?? '' }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                </label>
                <label class="block">
                    <span class="mb-2 block text-xs font-semibold text-[#56708e]">Sampai Tanggal</span>
                    <input type="date" name="end_date" value="{{ $filters['end_date'] ?? '' }}" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                </label>
                <label class="block">
                    <span class="mb-2 block text-xs font-semibold text-[#56708e]">Status</span>
                    <select name="status" class="w-full rounded-2xl border border-[#dce6f1] px-4 py-3 text-sm outline-none focus:border-pm-blue">
                        <option value="">Semua</option>
                        @foreach (['pending' => 'Pending', 'paid' => 'Paid', 'failed' => 'Failed', 'expired' => 'Expired', 'refunded' => 'Refunded'] as $value => $label)
                            <option value="{{ $value }}" @selected(($filters['status'] ?? '') === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                </label>
                <div class="flex items-end gap-2">
                    <button type="submit" class="rounded-full bg-pm-blue px-4 py-3 text-sm font-semibold text-white">Filter</button>
                    <a href="{{ route('admin.donations') }}" class="rounded-full border border-[#dce6f1] px-4 py-3 text-sm font-medium text-[#23405f]">Reset</a>
                    <button type="submit" formaction="{{ route('admin.donations.export') }}" class="rounded-full bg-[#18794e] px-4 py-3 text-sm font-semibold text-white">Export Excel</button>
                </div>
            </form>
        </div>

        <div class="overflow-x-auto px-5 py-5">
            <table class="min-w-full text-left text-sm">
                <thead class="text-[#56708e]">
                    <tr class="border-b border-[#e9eff6]">
                        <th class="pb-3 font-semibold">Reference</th>
                        <th class="pb-3 font-semibold">Campaign</th>
                        <th class="pb-3 font-semibold">Donor</th>
                        <th class="pb-3 font-semibold">Transfer</th>
                        <th class="pb-3 font-semibold">Status</th>
                        <th class="pb-3 font-semibold">Dibuat</th>
                        <th class="pb-3 font-semibold text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($donations as $donation)
                        <tr class="border-b border-[#eef3f8] last:border-b-0">
                            <td class="py-3 font-mono text-xs text-[#123457]">
                                <a href="{{ route('admin.donations.show', $donation) }}" class="text-pm-blue hover:underline">{{ $donation->reference }}</a>
                                @if($donation->prayer_message)
                                    <span title="Ada pesan/doa" class="ml-1 inline-block rounded-full bg-blue-100 p-1 text-pm-blue align-middle">
                                        <svg class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                                    </span>
                                @endif
                            </td>
                            <td class="py-3 text-[#123457]">{{ $donation->campaign?->title ?? '-' }}</td>
                            <td class="py-3 text-[#123457]">
                                <p>{{ $donation->is_anonymous ? 'Anonim' : $donation->donor_name }}</p>
                                <p class="mt-1 text-xs text-[#56708e]">{{ $donation->donor_phone }}</p>
                            </td>
                            <td class="py-3 text-[#123457]">
                                <p class="font-semibold">Rp {{ number_format((float) $donation->amount, 0, ',', '.') }}</p>
                                <p class="mt-1 text-xs text-[#56708e]">Donasi Rp {{ number_format((float) ($donation->base_amount ?: $donation->amount), 0, ',', '.') }} + kode {{ number_format((int) $donation->unique_code, 0, ',', '.') }}</p>
                            </td>
                            <td class="py-3"><span class="rounded-full bg-[#eef5ff] px-3 py-1 text-xs font-semibold text-pm-blue">{{ str($donation->status)->headline() }}</span></td>
                            <td class="py-3 text-[#56708e]">
                                <p>{{ $donation->created_at->format('d M Y H:i') }}</p>
                                @if ($donation->expires_at)
                                    <p class="mt-1 text-xs">Expired {{ $donation->expires_at->format('d M Y H:i') }}</p>
                                @endif
                                @if ($donation->verified_at)
                                    <p class="mt-1 text-xs text-[#18794e]">Verifikasi {{ $donation->verified_at->format('d M Y H:i') }}</p>
                                @endif
                            </td>
                            <td class="py-3">
                                @if ($donation->status === 'pending')
                                    <form method="POST" action="{{ route('admin.donations.status', $donation) }}" class="ml-auto grid min-w-[260px] gap-2" data-status-form>
                                        @csrf
                                        @method('PATCH')
                                        <input type="hidden" name="status" value="">
                                        <textarea name="admin_note" rows="2" class="w-full rounded-2xl border border-[#dce6f1] px-3 py-2 text-xs outline-none focus:border-pm-blue" placeholder="Catatan admin opsional">{{ old('admin_note', $donation->admin_note) }}</textarea>
                                        <div class="flex flex-wrap justify-end gap-2">
                                            @foreach (['paid' => 'Tandai Paid', 'failed' => 'Failed', 'expired' => 'Expired'] as $status => $label)
                                                <button
                                                    type="button"
                                                    class="rounded-full border border-[#dce6f1] px-3 py-1.5 text-xs font-medium text-[#23405f] transition hover:border-[#b8cce0] hover:bg-[#f5f9fc]"
                                                    data-donation-status-action
                                                    data-donation-status="{{ $status }}"
                                                    data-donation-status-label="{{ $label }}"
                                                >
                                                    {{ $label }}
                                                </button>
                                            @endforeach
                                        </div>
                                    </form>
                                @else
                                    <div class="min-w-[260px] space-y-2 rounded-2xl border border-[#e6edf6] bg-[#fbfdff] px-4 py-3">
                                        <p class="text-xs font-semibold uppercase tracking-[0.14em] text-[#56708e]">Status final</p>
                                        <p class="text-sm leading-6 text-[#31465d]">Transaksi ini sudah selesai, jadi tombol aksi dimatikan.</p>
                                        @if ($donation->admin_note)
                                            <p class="text-xs leading-5 text-[#56708e]">Catatan: {{ $donation->admin_note }}</p>
                                        @endif
                                    </div>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="py-8 text-center text-sm text-[#56708e]">Belum ada donasi masuk.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="border-t border-[#e4edf6] px-5 py-4">
            {{ $donations->links() }}
        </div>
    </section>

    <div
        class="fixed inset-0 z-50 hidden items-center justify-center bg-[#123457]/55 px-4 py-6"
        data-status-modal
        aria-hidden="true"
    >
        <div class="w-full max-w-lg overflow-hidden rounded-[28px] border border-[#d6e4f1] bg-white shadow-[0_24px_70px_rgba(10,32,58,0.28)]">
            <div class="bg-[linear-gradient(135deg,#123457,#0f5ca8)] px-6 py-5 text-white">
                <p class="text-[10px] font-semibold uppercase tracking-[0.24em] text-blue-100">Konfirmasi Verifikasi</p>
                <h3 class="mt-2 font-display text-3xl leading-none">Pastikan data mutasi sudah cocok</h3>
            </div>

            <div class="space-y-4 px-6 py-6">
                <div class="rounded-2xl border border-[#f2d58f] bg-[#fff9e8] px-4 py-4 text-sm leading-7 text-[#7b5b00]">
                    <p class="font-semibold">Sebelum melanjutkan</p>
                    <p class="mt-1">Cek mutasi rekening, pastikan nominal dan referensi sudah benar, lalu lanjutkan status transaksi ini.</p>
                </div>

                <div class="rounded-2xl border border-[#dce6f1] bg-[#f8fbff] px-4 py-4">
                    <p class="text-[10px] uppercase tracking-[0.14em] text-[#56708e]">Aksi yang dipilih</p>
                    <p class="mt-2 text-lg font-semibold text-[#123457]" data-status-modal-label>Tandai Paid</p>
                </div>

                <div class="flex flex-wrap justify-end gap-3">
                    <button type="button" class="rounded-full border border-[#dce6f1] px-5 py-3 text-sm font-medium text-[#23405f]" data-status-modal-cancel>Batal</button>
                    <button type="button" class="rounded-full bg-pm-blue px-5 py-3 text-sm font-semibold text-white shadow-[0_10px_22px_rgba(15,92,168,0.22)]" data-status-modal-confirm>Ya, lanjutkan</button>
                </div>
            </div>
        </div>
    </div>
@endsection

<?php

namespace Tests\Feature;

use App\Models\Campaign;
use App\Models\CampaignCategory;
use App\Models\Donation;
use App\Models\PaymentTransaction;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PublicDonationFlowTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_user_can_submit_bank_transfer_donation_and_create_pending_transaction(): void
    {
        $category = CampaignCategory::query()->create([
            'name' => 'Humanity',
            'slug' => 'humanity',
            'description' => 'Program kemanusiaan',
            'is_active' => true,
            'sort_order' => 1,
        ]);

        $campaign = Campaign::query()->create([
            'campaign_category_id' => $category->id,
            'title' => 'Teman Pulih',
            'slug' => 'teman-pulih',
            'organizer_name' => 'Yayasan Peduli Harapan',
            'featured_badge' => 'Teman Pulih',
            'cta_label' => 'Donasi Sekarang',
            'summary' => 'Ringkasan campaign teman pulih.',
            'content' => 'Konten campaign teman pulih.',
            'target_amount' => 5000000,
            'current_amount' => 1000000,
            'donor_count' => 10,
            'start_date' => now()->subDays(1)->toDateString(),
            'end_date' => now()->addDays(20)->toDateString(),
            'publish_status' => 'published',
            'public_status' => 'active',
            'is_featured' => false,
            'display_order' => 1,
        ]);

        $response = $this->post(route('donation.store', $campaign->slug), [
            'amount' => '100000',
            'donor_name' => 'Rahmawati',
            'donor_email' => 'rahmawati@example.com',
            'donor_phone' => '081200000001',
            'prayer_message' => 'Semoga bermanfaat.',
            'is_anonymous' => '1',
        ]);

        $donation = Donation::query()->first();

        $response->assertRedirect(route('donation.show', $donation?->reference));
        $this->assertNotNull($donation);
        $this->assertSame($campaign->id, $donation->campaign_id);
        $this->assertSame('Rahmawati', $donation->donor_name);
        $this->assertSame('pending', $donation->status);
        $this->assertTrue($donation->is_anonymous);
        $this->assertSame('100000.00', $donation->base_amount);
        $this->assertGreaterThanOrEqual(1, $donation->unique_code);
        $this->assertLessThanOrEqual(999, $donation->unique_code);
        $this->assertSame(100000 + $donation->unique_code, (int) $donation->amount);
        $this->assertSame('BSI', $donation->payment_bank);
        $this->assertSame('7063488245', $donation->payment_account_number);
        $this->assertDatabaseHas('payment_transactions', [
            'donation_id' => $donation?->id,
            'gateway' => 'bank_transfer',
            'status' => 'pending',
        ]);
        $this->assertSame(1, PaymentTransaction::query()->count());
    }
}

@extends('layouts.admin')

@section('content')
    <section class="rounded-[26px] bg-white shadow-[0_14px_28px_rgba(14,44,82,0.08)]">
        <div class="border-b border-[#e4edf6] px-5 py-5">
            <p class="text-[10px] font-semibold uppercase tracking-[0.18em] text-pm-blue">Modul Administrasi</p>
            <h2 class="mt-1 font-display text-3xl leading-none text-[#123457]">{{ $page['title'] }}</h2>
            <p class="mt-3 max-w-3xl text-sm leading-7 text-[#56708e]">{{ $page['description'] }}</p>
        </div>

        <div class="overflow-x-auto px-5 py-5">
            <table class="min-w-full text-left text-sm">
                <thead class="text-[#56708e]">
                    <tr class="border-b border-[#e9eff6]">
                        <th class="pb-3 font-semibold">Nama</th>
                        <th class="pb-3 font-semibold">Email</th>
                        <th class="pb-3 font-semibold">Telepon</th>
                        <th class="pb-3 font-semibold">Total Donasi</th>
                        <th class="pb-3 font-semibold">Jumlah Donasi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($donors as $donor)
                        <tr class="border-b border-[#eef3f8] last:border-b-0">
                            <td class="py-3 font-medium text-[#123457]">{{ $donor->name }}</td>
                            <td class="py-3 text-[#123457]">{{ $donor->email ?: '-' }}</td>
                            <td class="py-3 text-[#123457]">{{ $donor->phone ?: '-' }}</td>
                            <td class="py-3 text-[#123457]">Rp {{ number_format((float) ($donor->donations_sum_amount ?? 0), 0, ',', '.') }}</td>
                            <td class="py-3 text-[#123457]">{{ $donor->donations_count }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="py-8 text-center text-sm text-[#56708e]">Belum ada donor yang tercatat.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="border-t border-[#e4edf6] px-5 py-4">
            {{ $donors->links() }}
        </div>
    </section>
@endsection
